import login from "./login/index.js";
import get_login_history from "./get_login_history/index.js"

export default 
[
[login, "login"],
[get_login_history,"get_login_history"]
];